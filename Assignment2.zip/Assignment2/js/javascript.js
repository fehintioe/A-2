document.addEventListener('DOMContentLoaded', () => {
    console.log("Page loaded");
    // Additional JS functionality here
});
